# Load the required libraries
library("tidyverse")
library("readxl")
library(dplyr)
library(maptools)
library(lattice)
library(spdep)
library(sp)
library(rgdal)
library(tmap)
library(ggplot2)
library(gridExtra)
library(gstat)
library(OpenStreetMap)
library(spacetime)
library(here)
library(fs)
library("Metrics")
library(kernlab)
library(maptools)
library(sp)
library("knitr")
library(ggplot2)
library(lattice)
library(caret)
library(scales)
###read median house price data (2006-01-01 -- 2020-12-01) #all months 15 years (180 months)
house_price <- read_excel("data/STDM_data.xlsx")

##check type of attribute data
Typelist <- house_price %>%
  summarise_all(class) %>%
  pivot_longer(everything(),
               names_to="Features",
               values_to="Feature_type")
##data that only contain house price
house_price_matrix<-data.matrix(house_price[,2:ncol(house_price)])
#rownames(house_price_matrix) <- house_price$Area
is.null(house_price_matrix)
#the average house price across London between 2006 to 2020 was  410724.2 and the standard deviation was 202715.3
mu = mean(house_price_matrix)
mu
sdev = sd(house_price_matrix)
sdev

###
house_price_1 <- boxplot(house_price$"Camden", main="Boxplot of house price in Islington",
                        ylab="house price",col = "#69b3a2")
house_price_1

plot(house_price_matrix[,1], xlab = "Number of month", ylab = "Islington house price", type="l", xaxt="n")
#axis(1,xlim=c(1,180))
axis(1, at = seq(0, 180, 10), labels=seq(0, 180, 10))
title("Temproal trend of house price in Islington")

plot(house_price_matrix[,3], xlab = "Number of month", ylab = "Lambeth house price", type="l", xaxt="n")
#axis(1,xlim=c(1,180))
axis(1, at = seq(0, 180, 10), labels=seq(0, 180, 10))
title("Temproal trend of house price in Lambeth")

plot(house_price_matrix[,7], xlab = "Number of month", ylab = "Barnet house price", type="l", xaxt="n")
#axis(1,xlim=c(1,180))
axis(1, at = seq(0, 180, 10), labels=seq(0, 180, 10))
title("Temproal trend of house price in Barnet")

plot(house_price_matrix[,8], xlab = "Number of month", ylab = "Bexley house price", type="l", xaxt="n")
#axis(1,xlim=c(1,180))
axis(1, at = seq(0, 180, 10), labels=seq(0, 180, 10))
title("Temproal trend of house price in Bexley")

hist_df <- as.data.frame(as.numeric(house_price_matrix))
names(hist_df) <- "price"
###explore the normality of dataset gather(as.data.frame(house_price_matrix), cols, value), aes(x = value)
hist_house_price <- ggplot(data = hist_df,mapping = aes(x =price)) +
  ggtitle("Distribution of house prices in London")+
  theme(plot.title = element_text(hjust = 0.5),legend.position = c(0.85, 0.85))+
  geom_histogram(mapping = aes(y = stat(density)),bins = 15,fill="#69b3a2", color="#e9ecef") +
  geom_density(color = "red", size = 1,alpha = .2)+
  geom_vline(aes(xintercept=mean(price, na.rm=T),color="mean"),
             linetype="dashed", size=1)+
  geom_vline(aes(xintercept=median(price, na.rm=T),color="median"),
             linetype="dashed", size=1)+
  scale_color_manual(name = "mean and median", values = c(median = "blue", mean = "orange"))

hist_house_price

hist(house_price_matrix)
abline(v=mu, col="red")

qqnorm(house_price_matrix)
qqline(house_price_matrix, col="red")
#the data is not normally distributed.


###explore temporal characteristics

#transpose dataframe
trans_house_price <- as.data.frame(t(house_price))
colnames(trans_house_price) <- trans_house_price[1,]
trans_house_price <- trans_house_price[-1,]
trans_house_price <- cbind(Borough = rownames(trans_house_price),trans_house_price)
rownames(trans_house_price) <- 1:nrow(trans_house_price)
#house_price_trans_matrix<-data.matrix(trans_house_price[,2:ncol(trans_house_price)])
#house_price_trans_matrix <-matrix(as.numeric(house_price_trans_matrix),ncol=ncol(house_price_trans_matrix))

#house price temporal trend for the whole london
plot(rowMeans(house_price_matrix), xlab = "Number of month", ylab = "house price", type="l", xaxt="n")
#axis(1,xlim=c(1,180))
axis(1, at = seq(0, 180, 10), labels=seq(0, 180, 10))
title("Temproal trend of house prices in London")

#Create the heatmap:
heatmap(house_price_matrix,Rowv=NA,Colv=NA, col=heat.colors(256),scale="column", margins=c(14,3),xlab="borough",ylab="month", cexCol=1.1,y.scale.components.subticks(n=10))
#it can be seen that the temporal variation in house price is much larger than the spatial variation


######explore spatial characteristics

#set working directory accordingly with setwd()
# change this to your file path!!!
##download boundary data
download.file("https://data.london.gov.uk/download/statistical-gis-boundary-files-london/9ba8c833-6370-4b11-abdc-314aa020d5e0/statistical-gis-boundaries-london.zip", destfile="data/statistical-gis-boundaries-london.zip")

##unzip boundary data
zipfile<-dir_info(here::here("data")) %>%
  dplyr::filter(str_detect(path, ".zip")) %>%
  dplyr::select(path)%>%
  pull()%>%
  print()%>%
  as.character()%>%
  utils::unzip(exdir=here::here("data"))

#London Borough data is already in 277000
Londonborough <- st_read(here::here("data",
                                    "statistical-gis-boundaries-london",
                                    "ESRI",
                                    "London_Borough_Excluding_MHW.shp"))%>%
  st_transform(., 27700)


trans_house_price.df <- as.data.frame(trans_house_price)
trans_house_price.df[,-1] <- lapply(trans_house_price.df[,-1], as.numeric)

Typelistnew <- trans_house_price.df%>%
  summarise_all(class) %>%
  pivot_longer(everything(),
               names_to="Features",
               values_to="Feature_type")

##merge boundaries and geo data
joined_data <- Londonborough%>%
  left_join(.,
            trans_house_price.df,
            by = c("NAME" = "Borough"))

#tm_shape(joined_data)+
 # tm_fill("2019-01-01", style="fixed", palette="Purples",breaks=c(70,80,90,100,150))+
  #tm_borders("white")+
  #tm_compass(position=c("left","top"))+
  #tm_scale_bar()

tmap_mode("plot")

Londonbb <- st_bbox(joined_data,
                    crs = st_crs(joined_data)) %>%
  st_as_sfc()

#joined_data$`obesity rate` = joined_data$obesity_rate
spatial_map_2008 <- tm_shape(joined_data) +
  tm_polygons("2008-01-01",palette="-RdYlBu",title ="house price",breaks= c(190000,390000,590000,790000,990000))+
  #tmap_options(max.categories=33)+
  tm_scale_bar(position = c("right", "bottom"), text.size = .8)+
  tm_layout(
    legend.position = c(0.8,0.3),
    legend.text.size=.8,
    legend.title.size = 1.1,
    legend.show = TRUE,
    main.title = "House price distribution in 2008-01",
    main.title.position = "center",
    main.title.color = "black",
    main.title.size = 1.2,
    frame=FALSE)+
  tm_compass(north=0, position = c(0.8, 0.15),size =3) +
  #bottom left top right
  tm_layout(inner.margin=c(0.02,0.02,0.02,0.2))

spatial_map_2008


spatial_map_2012 <- tm_shape(joined_data) +
  tm_polygons("2012-01-01",palette="-RdYlBu",title ="house price",breaks= c(160000,360000,560000,760000,960000))+
  tmap_options(max.categories=33)+
  tm_scale_bar(position = c("right", "bottom"), text.size = .8)+
  tm_layout(
    legend.position = c(0.8,0.3),
    legend.text.size=.8,
    legend.title.size = 1.1,
    legend.show = TRUE,
    main.title = "House price distribution in 2012-01",
    main.title.position = "center",
    main.title.color = "black",
    main.title.size = 1.2,
    frame=FALSE)+
  tm_compass(north=0, position = c(0.8, 0.15),size =3) +
  #bottom left top right
  tm_layout(inner.margin=c(0.02,0.02,0.02,0.2))

spatial_map_2012


spatial_map_2016 <- tm_shape(joined_data) +
  tm_polygons("2016-01-01",palette="-RdYlBu",title ="house price",breaks= c(250000,550000,850000,1150000,1450000))+
  tmap_options(max.categories=33)+
  tm_scale_bar(position = c("right", "bottom"), text.size = .8)+
  tm_layout(
    legend.position = c(0.8,0.3),
    legend.text.size=.8,
    legend.title.size = 1.1,
    legend.show = TRUE,
    main.title = "House price distribution in 2016-01",
    main.title.position = "center",
    main.title.color = "black",
    main.title.size = 1.2,
    frame=FALSE)+
  tm_compass(north=0, position = c(0.8, 0.15),size =3) +
  #bottom left top right
  tm_layout(inner.margin=c(0.02,0.02,0.02,0.2))

spatial_map_2016



spatial_map_2020 <- tm_shape(joined_data) +
  tm_polygons("2020-01-01",palette="-RdYlBu",title ="house price",breaks= c(300000,600000,900000,1200000,1500000))+
  tmap_options(max.categories=33)+
  tm_scale_bar(position = c("right", "bottom"), text.size = .8)+
  tm_layout(
    legend.position = c(0.8,0.3),
    legend.text.size=.8,
    legend.title.size = 1.1,
    legend.show = TRUE,
    main.title = "House price distribution in 2020-01",
    main.title.position = "center",
    main.title.color = "black",
    main.title.size = 1.2,
    frame=FALSE)+
  tm_compass(north=0, position = c(0.8, 0.15),size =3) +
  #bottom left top right
  tm_layout(inner.margin=c(0.02,0.02,0.02,0.2))

spatial_map_2020


BoroughMeanHousePrice <- rowMeans(house_price[,-1])
ChLagged <- data.frame(month = 1:179, t=BoroughMeanHousePrice[2:(length(BoroughMeanHousePrice))], t_minus_1=BoroughMeanHousePrice[1:(length(BoroughMeanHousePrice)-1)])
p1 <- ggplot(ChLagged, aes(x=month, y=t)) + geom_line()
p2 <- ggplot(ChLagged, aes(x=t, y=t_minus_1)) +
  geom_point() +
  labs(y="t-1") +
  geom_smooth(method="lm") # Add a regression line to the plot

# Calculate PMCC
PMCC=paste("r =", round(cor(ChLagged$t, ChLagged$t_minus_1), 3))
PMCC
grid.arrange(p1,p2, nrow=1)

acf(BoroughMeanHousePrice, lag.max=50)
acf(house_price_matrix[,"Camden"], lag.max=50, main="ACF, Camden")
acf(house_price_matrix[,"Brent"], lag.max=50, main="ACF, Brent")

pacf(house_price_matrix[,"Camden"], lag.max=50, main="PACF, Camden")
pacf(house_price_matrix[,"Brent"], lag.max=50, main="PACF, Brent")

pacf(BoroughMeanHousePrice, lag.max=50, main="PACF, boroughmean")

#calculate the centroids of all Wards in London
coordsW <- joined_data%>%
  st_centroid()%>%
  st_geometry()
plot(coordsW)

W <- nb2listw(poly2nb(joined_data))
W

library(knitr)
kable(listw2mat(W))
house_price_avg <- colMeans(house_price_matrix)
#moran.test(x=house_price_avg, listw=W)

#moran.mc(x=house_price_avg, listw=W, nsim=9999)

lm <- localmoran(x=colMeans(house_price_matrix), listw=W)
lm

source("practical_data/starima_package.R")
Wmat <- listw2mat(W)
stacf(house_price_matrix, Wmat, 48)
stpacf(house_price_matrix, Wmat, 4)


###model building

### support vector machine regression
house_price_matrix <- rescale(house_price_matrix)
house_price_df <-as.data.frame(house_price_matrix)
#house_price_df_selected <- data.frame(select(house_price_df,"Camden","Barnet","Brent"))
load("practical_data/SVMRegressionWS.RData")
load("practical_data/classificationWS.RData")
sptmseries <- st_embed(data= house_price_df, m=3, col=6, W=W, ii=TRUE)
n <- nrow(sptmseries$y)
trainMonth <- ceiling(n*0.8/12)
split <- 12*trainMonth
sptmtr <- sptmseries$X[1:split,]
sptmts <- sptmseries$X[(split+1):nrow(sptmseries$X),]
sptmytr <- sptmseries$y[1:split,]
sptmyts <- sptmseries$y[(split+1):nrow(sptmseries$y),]
colnames(sptmtr) <- c("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15")
set.seed(123)
SVRgrid <- expand.grid(.sigma=c(0.001, 0.01, 0.1), .C=c(10,100,1000))
ctrl <- trainControl(method = "cv", number=5)
SVRGridFit <- train(sptmtr, sptmytr, method="svmRadial", tuneGrid=SVRgrid,epsilon=0.01,
                      trControl=ctrl, type="eps-svr")
SVRGridFit
plot(SVRGridFit)
names(SVRGridFit)
SVRGridFit$finalModel
SVRGridFit$finalModel@nSV
stforecast <- predict(SVRGridFit$finalModel, sptmts)
plot(sptmyts, type="l", xlab="Number of month", ylab="Camden house price",col = "red")
lines(stforecast,col = "blue")
axis(1,33)
legend("topright", legend=c("Observed","Predicted"), lty=1, bty="n",col = c("red","blue"))
#stmodel <- ksvm(x=sptmtr,y=sptmytr,type="eps-svr",kernel="rbfdot", kpar=list(sigma=0.1), C=1000, epsilon=0.001, cross=5)
#plot(house_price_matrix[,"Camden"],type="l")
rmseSVRTs <- rmse(sptmyts, stforecast)
rmseSVRTr <- rmse(sptmytr, predict(SVRGridFit, sptmtr))
mapeSVRTs<- mape(sptmyts,stforecast)
mapeSVRTr <- mape(sptmytr, predict(SVRGridFit, sptmtr))


stSVRResidual <- sptmyts-stforecast
plot(stSVRResidual)
acf(stSVRResidual)

### neural network
library(nnet) #install if necessary
library(caret)
mygrid <- expand.grid(.decay=c(0.1,0.01,0.001,0.0001, 0.5,0.05,0.005,0.0005), .size=c(3, 4, 5, 6, 7, 8, 9, 10))
set.seed(123)
fitControl <- trainControl("repeatedcv", number = 10, repeats = 3, returnResamp = "all")
housing.nnet.cv <- train(sptmtr, sptmytr,"nnet", trControl = fitControl, tuneGrid=mygrid)
plot(housing.nnet.cv)
print(housing.nnet.cv)
housing.nnet.cv$finalModel
summary(housing.nnet.cv$finalModel)
library(devtools)
source_url('https://gist.githubusercontent.com/fawda123/7471137/raw/466c1474d0a505ff044412703516c34f1a4684a5/nnet_plot_update.r')
plot.nnet(housing.nnet.cv$finalModel)

NN.nnet <- nnet(sptmtr, sptmytr, decay=1e-04, linout = TRUE, size=4)
NN.pred<-predict(NN.nnet, sptmts)
NN.pred[,1]
plot(sptmyts, type="l", xlab="Number of month", ylab="Camden house price",col = "red")
lines(NN.pred[,1],col = "blue")
axis(1,33)
legend("topright", legend=c("Observed","Predicted"), lty=1, bty="n",col = c("red","blue"))


rmseNNTs <- rmse(sptmyts, NN.pred[,1])
rmseNNSTr <- rmse(sptmytr, predict(NN.nnet, sptmtr))
mapeNNSTs<- mape(sptmyts,NN.pred[,1])
mapeNNSTr <- mape(sptmytr, predict(NN.nnet, sptmtr))


### random forest
# Random Search
rfgrid <- expand.grid(.mtry=c(1:15))
control <- trainControl(method="repeatedcv", number=10, repeats=3, search="grid")
set.seed(123)
rf_grid <- train(sptmtr,sptmytr, method="rf",ntrees = 100, trControl=control,tuneGrid=rfgrid)
print(rf_grid)
plot(rf_grid)
rf.pred<-predict(rf_grid$finalModel, sptmts)
rf.pred
plot(sptmyts, type="l", xlab="Number of month", ylab="Camden house price",col = "red")
lines(rf.pred,col = "blue")
axis(1,33)
legend("topright", legend=c("Observed","Predicted"), lty=1, bty="n",col = c("red","blue"))

rmseRFSTs <- rmse(sptmyts, rf.pred)
rmseRFSTr <- rmse(sptmytr, predict(rf_grid$finalModel, sptmtr))
mapeRFSTs<- mape(sptmyts,rf.pred)
mapeRFSTr <- mape(sptmytr, predict(rf_grid$finalModel, sptmtr))


mydata <- data.frame(Camden = c(0.0245,0.0191,0.0174), Islington=c(0.0159,0.0121,0.0095),Kensington=c(0.0277,0.0365,0.0272),Lambeth=c(0.0089,0.0088,0.0058),
                     Lewisham=c(0.0085,0.0076,0.0039),Barking=c(0.0083,0.0087,0.0033),Barnet=c(0.0081,0.0091,0.0044),Bexley=c(0.0043,0.0043,0.0026),
                     Brent=c(0.0116,0.0149,0.0116), Bromley=c(0.0038,0.0045,0.0032))
barplot(as.matrix(mydata), main="Prediction performance of modles in different boroughs", ylab="RMSE",xlab = "Borough", beside=TRUE,
        col=terrain.colors(3))
legend("topright",c("SVR","RF","ANN"), cex=0.9,
       fill=terrain.colors(3))
